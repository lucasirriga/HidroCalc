# Walkthrough: IA no HidroCalc

...

### Arquivos Modificados

* `plugin.py`: Adicionados métodos `list_layers` e `list_nearest_stations`.
